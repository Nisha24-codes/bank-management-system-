import math
import random
import datetime
from decimal import Decimal, InvalidOperation
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__, template_folder="frontend", static_folder="static")
app.secret_key = "nivra-banking-super-secret-key-prod-2026"

# MySQL connection settings
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "paramu45",
    "database": "nivra_banking"
}


def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)


def login_required(route_function):
    @wraps(route_function)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to access this page.", "error")
            return redirect(url_for("login"))
        return route_function(*args, **kwargs)
    return wrapper


def generate_account_number():
    return f"NIVRA{random.randint(100000, 999999)}"


def generate_card_details():
    card_no = f"5424 {random.randint(1000, 9999)} {random.randint(1000, 9999)} {random.randint(1000, 9999)}"
    cvv = f"{random.randint(100, 999)}"
    expiry_year = datetime.datetime.now().year + 4
    expiry = f"{random.randint(1, 12):02d}/{str(expiry_year)[-2:]}"
    return card_no, cvv, expiry


def calculate_emi(principal, annual_rate, months):
    try:
        p = float(principal)
        r = float(annual_rate) / (12 * 100)
        n = int(months)
        if n <= 0 or p <= 0:
            return 0.0
        if r == 0:
            return round(p / n, 2)
        emi = (p * r * math.pow(1 + r, n)) / (math.pow(1 + r, n) - 1)
        return round(emi, 2)
    except Exception:
        return 0.0


def calculate_fd_maturity(principal, annual_rate, months):
    try:
        p = float(principal)
        r = float(annual_rate) / 100.0
        t = float(months) / 12.0
        # Quarterly compounding
        maturity = p * math.pow((1 + (r / 4)), 4 * t)
        return round(maturity, 2)
    except Exception:
        return round(float(principal), 2)


def initialize_database():
    """Ensure all required tables and columns exist safely."""
    conn = get_db_connection()
    cursor = conn.cursor()

    # 1. Users table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS app_users (
            user_id INT PRIMARY KEY AUTO_INCREMENT,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # 2. Customers table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id INT PRIMARY KEY AUTO_INCREMENT,
            full_name VARCHAR(100) NOT NULL,
            email VARCHAR(100) UNIQUE,
            phone VARCHAR(20),
            address VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # 3. Accounts table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS accounts (
            account_id INT PRIMARY KEY AUTO_INCREMENT,
            customer_id INT NOT NULL,
            account_number VARCHAR(30) UNIQUE NOT NULL,
            account_type VARCHAR(20) NOT NULL DEFAULT 'Savings',
            balance DECIMAL(12,2) DEFAULT 0.00,
            status VARCHAR(20) DEFAULT 'Active',
            card_number VARCHAR(25),
            card_expiry VARCHAR(10),
            card_cvv VARCHAR(4),
            card_status VARCHAR(20) DEFAULT 'Active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        )
    """)

    # 4. Transactions table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            transaction_id INT PRIMARY KEY AUTO_INCREMENT,
            account_id INT NOT NULL,
            transaction_type VARCHAR(30) NOT NULL,
            amount DECIMAL(12,2) NOT NULL,
            transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            description VARCHAR(255),
            reference_account VARCHAR(50),
            FOREIGN KEY (account_id) REFERENCES accounts(account_id)
        )
    """)

    # 5. Loans table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS loans (
            loan_id INT PRIMARY KEY AUTO_INCREMENT,
            customer_id INT NOT NULL,
            amount DECIMAL(12,2) NOT NULL,
            purpose VARCHAR(255),
            interest_rate DECIMAL(5,2) DEFAULT 8.50,
            tenure_months INT DEFAULT 12,
            monthly_emi DECIMAL(10,2) DEFAULT 0.00,
            status VARCHAR(20) DEFAULT 'Pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        )
    """)

    # 6. Fixed Deposits table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS fixed_deposits (
            fd_id INT PRIMARY KEY AUTO_INCREMENT,
            account_id INT NOT NULL,
            customer_id INT NOT NULL,
            principal_amount DECIMAL(12,2) NOT NULL,
            interest_rate DECIMAL(5,2) NOT NULL,
            tenure_months INT NOT NULL,
            maturity_amount DECIMAL(12,2) NOT NULL,
            start_date DATE NOT NULL,
            maturity_date DATE NOT NULL,
            status VARCHAR(20) DEFAULT 'Active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (account_id) REFERENCES accounts(account_id),
            FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
        )
    """)

    conn.commit()
    cursor.close()
    conn.close()


# ---------- AUTHENTICATION ----------

@app.route("/")
def home():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM app_users WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["user_id"]
            session["user_name"] = user["full_name"]
            session["user_email"] = user["email"]
            flash(f"Welcome back, {user['full_name']}!", "success")
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "error")

    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not name or not email or len(password) < 8:
            flash("Please enter all details. Password must be at least 8 characters.", "error")
            return render_template("register.html")

        conn = get_db_connection()
        cursor = conn.cursor()

        try:
            cursor.execute(
                "INSERT INTO app_users (full_name, email, password_hash) VALUES (%s, %s, %s)",
                (name, email, generate_password_hash(password))
            )
            conn.commit()
            flash("Registration successful! Please log in with your credentials.", "success")
            return redirect(url_for("login"))
        except mysql.connector.IntegrityError:
            conn.rollback()
            flash("This email address is already registered.", "error")
        except Exception as e:
            conn.rollback()
            flash(f"Error during registration: {str(e)}", "error")
        finally:
            cursor.close()
            conn.close()

    return render_template("register.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been securely logged out.", "success")
    return redirect(url_for("login"))


# ---------- DASHBOARD ----------

@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Core statistics
    cursor.execute("SELECT COUNT(*) AS total FROM customers")
    total_customers = cursor.fetchone()["total"]

    cursor.execute("SELECT COUNT(*) AS total FROM accounts")
    total_accounts = cursor.fetchone()["total"]

    cursor.execute("SELECT COALESCE(SUM(balance), 0) AS total FROM accounts")
    total_balance = cursor.fetchone()["total"]

    cursor.execute("SELECT COUNT(*) AS total FROM transactions")
    total_transactions = cursor.fetchone()["total"]

    # Total deposits & withdrawals
    cursor.execute("""
        SELECT
            COALESCE(SUM(CASE WHEN transaction_type IN ('Deposit', 'Transfer In') THEN amount ELSE 0 END), 0) AS total_inflow,
            COALESCE(SUM(CASE WHEN transaction_type IN ('Withdraw', 'Transfer Out') THEN amount ELSE 0 END), 0) AS total_outflow
        FROM transactions
    """)
    flow = cursor.fetchone()
    total_inflow = flow["total_inflow"]
    total_outflow = flow["total_outflow"]

    # Active Fixed Deposits
    cursor.execute("SELECT COUNT(*) AS total, COALESCE(SUM(principal_amount), 0) AS total_val FROM fixed_deposits WHERE status = 'Active'")
    fd_stat = cursor.fetchone()
    total_active_fds = fd_stat["total"]
    total_fd_volume = fd_stat["total_val"]

    # Active Loans
    cursor.execute("SELECT COUNT(*) AS total, COALESCE(SUM(amount), 0) AS total_val FROM loans WHERE status = 'Approved'")
    loan_stat = cursor.fetchone()
    total_active_loans = loan_stat["total"]
    total_loan_volume = loan_stat["total_val"]

    # Recent 8 transactions with account number & customer name
    cursor.execute("""
        SELECT t.*, a.account_number, c.full_name
        FROM transactions t
        JOIN accounts a ON t.account_id = a.account_id
        JOIN customers c ON a.customer_id = c.customer_id
        ORDER BY t.transaction_date DESC
        LIMIT 8
    """)
    recent_transactions = cursor.fetchall()

    # Accounts for quick action modal/widget
    cursor.execute("""
        SELECT a.account_id, a.account_number, a.balance, c.full_name
        FROM accounts a
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE a.status = 'Active'
        ORDER BY c.full_name
    """)
    active_accounts = cursor.fetchall()

    # AI Financial Health Score calculation
    # Formula considers: Liquidity ratio, Transaction Activity, Accounts/Customers health
    health_score = 75
    if float(total_balance) > 50000:
        health_score += 15
    elif float(total_balance) > 10000:
        health_score += 10
    if total_transactions > 10:
        health_score += 8
    if float(total_inflow) >= float(total_outflow):
        health_score += 7
    else:
        health_score -= 10
    health_score = max(10, min(99, health_score))

    cursor.close()
    conn.close()

    return render_template(
        "dashboard.html",
        total_customers=total_customers,
        total_accounts=total_accounts,
        total_balance=total_balance,
        total_transactions=total_transactions,
        total_inflow=total_inflow,
        total_outflow=total_outflow,
        total_active_fds=total_active_fds,
        total_fd_volume=total_fd_volume,
        total_active_loans=total_active_loans,
        total_loan_volume=total_loan_volume,
        health_score=health_score,
        recent_transactions=recent_transactions,
        active_accounts=active_accounts
    )


# ---------- CUSTOMER MANAGEMENT ----------

@app.route("/customers", methods=["GET", "POST"])
@login_required
def customers():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        address = request.form.get("address", "").strip()

        if name:
            try:
                cursor.execute("""
                    INSERT INTO customers (full_name, email, phone, address)
                    VALUES (%s, %s, %s, %s)
                """, (name, email or None, phone or None, address or None))
                conn.commit()
                flash(f"Customer '{name}' added successfully!", "success")
            except mysql.connector.IntegrityError:
                conn.rollback()
                flash("A customer with this email address already exists.", "error")
            except Exception as e:
                conn.rollback()
                flash(f"Error adding customer: {str(e)}", "error")

    # Fetch customer list with their total accounts and balance
    cursor.execute("""
        SELECT c.*,
               COUNT(a.account_id) AS account_count,
               COALESCE(SUM(a.balance), 0) AS total_customer_balance
        FROM customers c
        LEFT JOIN accounts a ON c.customer_id = a.customer_id
        GROUP BY c.customer_id
        ORDER BY c.customer_id DESC
    """)
    customer_list = cursor.fetchall()

    cursor.close()
    conn.close()
    return render_template("customers.html", customers=customer_list)


@app.route("/customers/delete/<int:customer_id>", methods=["POST"])
@login_required
def delete_customer(customer_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        # Check if customer has active accounts with balance
        cursor.execute("SELECT COUNT(*) AS cnt, COALESCE(SUM(balance), 0) AS bal FROM accounts WHERE customer_id = %s", (customer_id,))
        acc_info = cursor.fetchone()
        if acc_info["bal"] > 0:
            flash(f"Cannot delete customer: they have active accounts with remaining balance ₹{acc_info['bal']}.", "error")
            return redirect(url_for("customers"))

        # Delete dependent rows in accounts, transactions if balance is zero
        cursor.execute("DELETE FROM loans WHERE customer_id = %s", (customer_id,))
        cursor.execute("DELETE FROM fixed_deposits WHERE customer_id = %s", (customer_id,))
        cursor.execute("DELETE FROM accounts WHERE customer_id = %s", (customer_id,))
        cursor.execute("DELETE FROM customers WHERE customer_id = %s", (customer_id,))
        conn.commit()
        flash("Customer removed successfully.", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Error removing customer: {str(e)}", "error")
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for("customers"))


# ---------- ACCOUNT MANAGEMENT ----------

@app.route("/accounts", methods=["GET", "POST"])
@login_required
def accounts():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        try:
            customer_id = int(request.form.get("customer_id", "0"))
            account_type = request.form.get("account_type", "Savings")
            opening_balance = Decimal(request.form.get("balance", "0"))

            if account_type not in ("Savings", "Current", "Salary", "Business") or opening_balance < 0:
                raise ValueError("Invalid account type or opening balance.")

            account_no = generate_account_number()
            card_no, card_cvv, card_expiry = generate_card_details()

            cursor.execute("""
                INSERT INTO accounts
                    (customer_id, account_number, account_type, balance, status, card_number, card_cvv, card_expiry, card_status)
                VALUES (%s, %s, %s, %s, 'Active', %s, %s, %s, 'Active')
            """, (customer_id, account_no, account_type, opening_balance, card_no, card_cvv, card_expiry))
            acc_id = cursor.lastrowid

            # If opening balance > 0, log opening deposit transaction
            if opening_balance > 0:
                cursor.execute("""
                    INSERT INTO transactions (account_id, transaction_type, amount, description)
                    VALUES (%s, 'Deposit', %s, 'Opening account initial deposit')
                """, (acc_id, opening_balance))

            conn.commit()
            flash(f"Account {account_no} created successfully with virtual debit card!", "success")
        except (ValueError, InvalidOperation) as e:
            conn.rollback()
            flash(str(e), "error")
        except mysql.connector.Error as e:
            conn.rollback()
            flash(f"Database error: {str(e)}", "error")

    cursor.execute("""
        SELECT a.*, c.full_name, c.email, c.phone
        FROM accounts a
        JOIN customers c ON a.customer_id = c.customer_id
        ORDER BY a.account_id DESC
    """)
    account_list = cursor.fetchall()

    cursor.execute("SELECT customer_id, full_name, email FROM customers ORDER BY full_name")
    customer_list = cursor.fetchall()

    cursor.close()
    conn.close()
    return render_template(
        "accounts.html",
        accounts=account_list,
        customers=customer_list
    )


@app.route("/accounts/toggle-status/<int:account_id>", methods=["POST"])
@login_required
def toggle_account_status(account_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT status FROM accounts WHERE account_id = %s", (account_id,))
        acc = cursor.fetchone()
        if acc:
            new_status = "Frozen" if acc["status"] == "Active" else "Active"
            cursor.execute("UPDATE accounts SET status = %s WHERE account_id = %s", (new_status, account_id))
            conn.commit()
            flash(f"Account status updated to {new_status}.", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Failed to update status: {str(e)}", "error")
    finally:
        cursor.close()
        conn.close()
    return redirect(url_for("accounts"))


# ---------- VIRTUAL CARDS MANAGEMENT ----------

@app.route("/cards")
@login_required
def cards():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT a.account_id, a.account_number, a.account_type, a.balance,
               a.card_number, a.card_expiry, a.card_cvv, a.card_status,
               c.full_name, c.email
        FROM accounts a
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE a.card_number IS NOT NULL
        ORDER BY a.account_id DESC
    """)
    card_list = cursor.fetchall()

    cursor.close()
    conn.close()
    return render_template("cards.html", cards=card_list)


@app.route("/cards/toggle-status/<int:account_id>", methods=["POST"])
@login_required
def toggle_card_status(account_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        cursor.execute("SELECT card_status FROM accounts WHERE account_id = %s", (account_id,))
        acc = cursor.fetchone()
        if acc:
            new_status = "Frozen" if acc["card_status"] == "Active" else "Active"
            cursor.execute("UPDATE accounts SET card_status = %s WHERE account_id = %s", (new_status, account_id))
            conn.commit()
            flash(f"Debit card has been {new_status.lower()}.", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Error toggling card: {str(e)}", "error")
    finally:
        cursor.close()
        conn.close()
    return redirect(url_for("cards"))


# ---------- TRANSACTIONS & TRANSFERS ----------

@app.route("/transactions", methods=["GET", "POST"])
@login_required
def transactions():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        action = request.form.get("transaction_type", "").strip()
        description = request.form.get("description", "").strip()

        try:
            amount = Decimal(request.form.get("amount", "0"))
            if amount <= 0:
                raise ValueError("Amount must be greater than zero.")

            # ---------- 1. DIRECT FUND TRANSFER (P2P / Inter-account) ----------
            if action == "Transfer":
                sender_id = int(request.form.get("sender_account_id", "0"))
                recipient_number = request.form.get("recipient_account_number", "").strip().upper()

                if not recipient_number:
                    raise ValueError("Please provide a recipient account number.")

                conn.start_transaction()

                # Lock sender
                cursor.execute("SELECT account_id, account_number, balance, status FROM accounts WHERE account_id = %s FOR UPDATE", (sender_id,))
                sender = cursor.fetchone()
                if not sender:
                    raise ValueError("Sender account not found.")
                if sender["status"] != "Active":
                    raise ValueError("Sender account is not Active.")
                if sender["balance"] < amount:
                    raise ValueError(f"Insufficient funds. Current balance: ₹{sender['balance']}")

                # Lock recipient
                cursor.execute("SELECT account_id, account_number, balance, status FROM accounts WHERE account_number = %s FOR UPDATE", (recipient_number,))
                recipient = cursor.fetchone()
                if not recipient:
                    raise ValueError(f"Recipient account '{recipient_number}' not found.")
                if recipient["account_id"] == sender["account_id"]:
                    raise ValueError("Cannot transfer funds to the same account.")
                if recipient["status"] != "Active":
                    raise ValueError("Recipient account is currently inactive or frozen.")

                # Debit sender
                cursor.execute("UPDATE accounts SET balance = balance - %s WHERE account_id = %s", (amount, sender["account_id"]))

                # Credit recipient
                cursor.execute("UPDATE accounts SET balance = balance + %s WHERE account_id = %s", (amount, recipient["account_id"]))

                # Insert Sender Transaction log (Transfer Out)
                cursor.execute("""
                    INSERT INTO transactions (account_id, transaction_type, amount, description, reference_account)
                    VALUES (%s, 'Transfer Out', %s, %s, %s)
                """, (sender["account_id"], amount, description or f"Transfer to {recipient['account_number']}", recipient["account_number"]))

                # Insert Recipient Transaction log (Transfer In)
                cursor.execute("""
                    INSERT INTO transactions (account_id, transaction_type, amount, description, reference_account)
                    VALUES (%s, 'Transfer In', %s, %s, %s)
                """, (recipient["account_id"], amount, description or f"Transfer from {sender['account_number']}", sender["account_number"]))

                conn.commit()
                flash(f"Successfully transferred ₹{amount} from {sender['account_number']} to {recipient['account_number']}!", "success")

            # ---------- 2. DEPOSIT & WITHDRAW ----------
            elif action in ("Deposit", "Withdraw"):
                account_id = int(request.form.get("account_id", "0"))

                conn.start_transaction()
                cursor.execute("SELECT balance, status, account_number FROM accounts WHERE account_id = %s FOR UPDATE", (account_id,))
                account = cursor.fetchone()

                if not account:
                    raise ValueError("Account not found.")
                if account["status"] != "Active":
                    raise ValueError(f"Account is {account['status']}. Operations not permitted.")

                if action == "Withdraw" and account["balance"] < amount:
                    raise ValueError(f"Insufficient funds! Current balance: ₹{account['balance']}")

                if action == "Deposit":
                    cursor.execute("UPDATE accounts SET balance = balance + %s WHERE account_id = %s", (amount, account_id))
                    desc = description or "Direct Cash Deposit"
                else:
                    cursor.execute("UPDATE accounts SET balance = balance - %s WHERE account_id = %s", (amount, account_id))
                    desc = description or "Cash Withdrawal"

                cursor.execute("""
                    INSERT INTO transactions (account_id, transaction_type, amount, description)
                    VALUES (%s, %s, %s, %s)
                """, (account_id, action, amount, desc))

                conn.commit()
                flash(f"{action} of ₹{amount} on account {account['account_number']} completed successfully.", "success")
            else:
                raise ValueError("Invalid transaction action.")

        except (ValueError, InvalidOperation) as error:
            conn.rollback()
            flash(str(error), "error")
        except mysql.connector.Error as error:
            conn.rollback()
            flash(f"Transaction failed: {str(error)}", "error")

    # Fetch filter options or full transaction history
    type_filter = request.args.get("type", "").strip()
    account_filter = request.args.get("account_id", "").strip()

    query = """
        SELECT t.*, a.account_number, c.full_name
        FROM transactions t
        JOIN accounts a ON t.account_id = a.account_id
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE 1=1
    """
    params = []
    if type_filter:
        query += " AND t.transaction_type = %s"
        params.append(type_filter)
    if account_filter:
        query += " AND t.account_id = %s"
        params.append(account_filter)

    query += " ORDER BY t.transaction_date DESC LIMIT 50"

    cursor.execute(query, tuple(params))
    transaction_list = cursor.fetchall()

    cursor.execute("""
        SELECT a.account_id, a.account_number, a.balance, c.full_name
        FROM accounts a
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE a.status = 'Active'
        ORDER BY c.full_name
    """)
    account_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "transactions.html",
        transactions=transaction_list,
        accounts=account_list,
        selected_type=type_filter,
        selected_account=account_filter
    )


# ---------- DEDICATED DEPOSIT MONEY ----------

@app.route("/deposit", methods=["GET", "POST"])
@login_required
def deposit():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        try:
            account_id = int(request.form.get("account_id", "0"))
            amount = Decimal(request.form.get("amount", "0"))
            description = request.form.get("description", "").strip() or "Cash Deposit"

            if amount <= 0:
                raise ValueError("Deposit amount must be greater than zero.")

            conn.start_transaction()
            cursor.execute("SELECT balance, status, account_number FROM accounts WHERE account_id = %s FOR UPDATE", (account_id,))
            account = cursor.fetchone()

            if not account:
                raise ValueError("Selected account was not found.")
            if account["status"] != "Active":
                raise ValueError(f"Account is {account['status']}. Deposits are not allowed.")

            cursor.execute("UPDATE accounts SET balance = balance + %s WHERE account_id = %s", (amount, account_id))
            cursor.execute("""
                INSERT INTO transactions (account_id, transaction_type, amount, description)
                VALUES (%s, 'Deposit', %s, %s)
            """, (account_id, amount, description))

            conn.commit()
            new_bal = account['balance'] + amount
            flash(f"Successfully deposited ₹{amount:,.2f} into Account {account['account_number']}. New Balance: ₹{new_bal:,.2f}", "success")
            return redirect(url_for("deposit", account_id=account_id))

        except (ValueError, InvalidOperation) as error:
            conn.rollback()
            flash(str(error), "error")
        except mysql.connector.Error as error:
            conn.rollback()
            flash(f"Deposit operation failed: {str(error)}", "error")

    # Fetch active accounts
    cursor.execute("""
        SELECT a.account_id, a.account_number, a.balance, a.account_type, c.full_name, c.email
        FROM accounts a
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE a.status = 'Active'
        ORDER BY c.full_name
    """)
    accounts_list = cursor.fetchall()

    selected_account_id = request.args.get("account_id", "")

    # Recent deposits
    cursor.execute("""
        SELECT t.*, a.account_number, c.full_name
        FROM transactions t
        JOIN accounts a ON t.account_id = a.account_id
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE t.transaction_type = 'Deposit'
        ORDER BY t.transaction_date DESC
        LIMIT 8
    """)
    recent_deposits = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "deposit.html",
        accounts=accounts_list,
        selected_account_id=selected_account_id,
        recent_deposits=recent_deposits
    )


# ---------- DEDICATED WITHDRAW MONEY ----------

@app.route("/withdraw", methods=["GET", "POST"])
@login_required
def withdraw():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        try:
            account_id = int(request.form.get("account_id", "0"))
            amount = Decimal(request.form.get("amount", "0"))
            description = request.form.get("description", "").strip() or "Cash Withdrawal"

            if amount <= 0:
                raise ValueError("Withdrawal amount must be greater than zero.")

            conn.start_transaction()
            cursor.execute("SELECT balance, status, account_number FROM accounts WHERE account_id = %s FOR UPDATE", (account_id,))
            account = cursor.fetchone()

            if not account:
                raise ValueError("Selected account was not found.")
            if account["status"] != "Active":
                raise ValueError(f"Account is {account['status']}. Withdrawals are not allowed.")

            if account["balance"] < amount:
                raise ValueError(f"Insufficient funds! Current balance is ₹{account['balance']:,.2f}, but you requested ₹{amount:,.2f}.")

            cursor.execute("UPDATE accounts SET balance = balance - %s WHERE account_id = %s", (amount, account_id))
            cursor.execute("""
                INSERT INTO transactions (account_id, transaction_type, amount, description)
                VALUES (%s, 'Withdraw', %s, %s)
            """, (account_id, amount, description))

            conn.commit()
            remaining_bal = account['balance'] - amount
            flash(f"Successfully withdrew ₹{amount:,.2f} from Account {account['account_number']}. Remaining Balance: ₹{remaining_bal:,.2f}", "success")
            return redirect(url_for("withdraw", account_id=account_id))

        except (ValueError, InvalidOperation) as error:
            conn.rollback()
            flash(str(error), "error")
        except mysql.connector.Error as error:
            conn.rollback()
            flash(f"Withdrawal operation failed: {str(error)}", "error")

    # Fetch active accounts
    cursor.execute("""
        SELECT a.account_id, a.account_number, a.balance, a.account_type, c.full_name, c.email
        FROM accounts a
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE a.status = 'Active'
        ORDER BY c.full_name
    """)
    accounts_list = cursor.fetchall()

    selected_account_id = request.args.get("account_id", "")

    # Recent withdrawals
    cursor.execute("""
        SELECT t.*, a.account_number, c.full_name
        FROM transactions t
        JOIN accounts a ON t.account_id = a.account_id
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE t.transaction_type = 'Withdraw'
        ORDER BY t.transaction_date DESC
        LIMIT 8
    """)
    recent_withdrawals = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "withdraw.html",
        accounts=accounts_list,
        selected_account_id=selected_account_id,
        recent_withdrawals=recent_withdrawals
    )


# ---------- FIXED DEPOSITS & SAVINGS VAULTS ----------


@app.route("/fixed-deposits", methods=["GET", "POST"])
@login_required
def fixed_deposits():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        try:
            account_id = int(request.form.get("account_id", "0"))
            principal = Decimal(request.form.get("principal_amount", "0"))
            tenure_months = int(request.form.get("tenure_months", "12"))

            # Interest rate ladder
            rate_map = {
                6: Decimal("6.50"),
                12: Decimal("7.25"),
                24: Decimal("7.50"),
                36: Decimal("8.00"),
                60: Decimal("8.50")
            }
            interest_rate = rate_map.get(tenure_months, Decimal("7.00"))

            if principal < 1000:
                raise ValueError("Minimum Fixed Deposit amount is ₹1,000.")

            conn.start_transaction()
            cursor.execute("SELECT customer_id, balance, status, account_number FROM accounts WHERE account_id = %s FOR UPDATE", (account_id,))
            acc = cursor.fetchone()

            if not acc:
                raise ValueError("Source account not found.")
            if acc["status"] != "Active":
                raise ValueError("Account is not active.")
            if acc["balance"] < principal:
                raise ValueError(f"Insufficient balance in account to open FD. Available: ₹{acc['balance']}")

            # Calculate maturity
            maturity_val = Decimal(str(calculate_fd_maturity(principal, interest_rate, tenure_months)))
            start_date = datetime.date.today()
            # Calculate approximate maturity date
            maturity_date = start_date + datetime.timedelta(days=int(tenure_months * 30.4))

            # Deduct principal from source account
            cursor.execute("UPDATE accounts SET balance = balance - %s WHERE account_id = %s", (principal, account_id))

            # Log transaction
            cursor.execute("""
                INSERT INTO transactions (account_id, transaction_type, amount, description)
                VALUES (%s, 'Withdraw', %s, %s)
            """, (account_id, principal, f"Opened Fixed Deposit for {tenure_months} months @ {interest_rate}%"))

            # Insert FD record
            cursor.execute("""
                INSERT INTO fixed_deposits
                    (account_id, customer_id, principal_amount, interest_rate, tenure_months, maturity_amount, start_date, maturity_date, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'Active')
            """, (account_id, acc["customer_id"], principal, interest_rate, tenure_months, maturity_val, start_date, maturity_date))

            conn.commit()
            flash(f"Fixed Deposit of ₹{principal} created successfully! Maturity value: ₹{maturity_val} on {maturity_date}.", "success")
        except (ValueError, InvalidOperation) as e:
            conn.rollback()
            flash(str(e), "error")
        except Exception as e:
            conn.rollback()
            flash(f"Failed to create FD: {str(e)}", "error")

    # Fetch active FDs
    cursor.execute("""
        SELECT f.*, a.account_number, c.full_name
        FROM fixed_deposits f
        JOIN accounts a ON f.account_id = a.account_id
        JOIN customers c ON f.customer_id = c.customer_id
        ORDER BY f.fd_id DESC
    """)
    fd_list = cursor.fetchall()

    cursor.execute("""
        SELECT a.account_id, a.account_number, a.balance, c.full_name
        FROM accounts a
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE a.status = 'Active'
    """)
    accounts_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template("fixed_deposits.html", fds=fd_list, accounts=accounts_list)


@app.route("/fixed-deposits/close/<int:fd_id>", methods=["POST"])
@login_required
def close_fixed_deposit(fd_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        conn.start_transaction()
        cursor.execute("SELECT * FROM fixed_deposits WHERE fd_id = %s FOR UPDATE", (fd_id,))
        fd = cursor.fetchone()

        if not fd:
            raise ValueError("FD record not found.")
        if fd["status"] != "Active":
            raise ValueError("This Fixed Deposit is already closed.")

        payout = fd["maturity_amount"] if datetime.date.today() >= fd["maturity_date"] else fd["principal_amount"]

        # Credit payout back to account
        cursor.execute("UPDATE accounts SET balance = balance + %s WHERE account_id = %s", (payout, fd["account_id"]))

        # Mark FD closed
        cursor.execute("UPDATE fixed_deposits SET status = 'Closed' WHERE fd_id = %s", (fd_id,))

        # Log transaction
        cursor.execute("""
            INSERT INTO transactions (account_id, transaction_type, amount, description)
            VALUES (%s, 'Deposit', %s, %s)
        """, (fd["account_id"], payout, f"Fixed Deposit #{fd_id} liquidation payout"))

        conn.commit()
        flash(f"Fixed Deposit #{fd_id} successfully liquidated! Credited ₹{payout} back to account.", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Error liquidating FD: {str(e)}", "error")
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for("fixed_deposits"))


# ---------- LOAN MANAGEMENT & EMI CALCULATOR ----------

@app.route("/loans", methods=["GET", "POST"])
@login_required
def loans():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == "POST":
        try:
            customer_id = int(request.form.get("customer_id", "0"))
            amount = Decimal(request.form.get("amount", "0"))
            purpose = request.form.get("purpose", "").strip()
            tenure_months = int(request.form.get("tenure_months", "12"))
            interest_rate = Decimal(request.form.get("interest_rate", "9.50"))

            if amount <= 0:
                raise ValueError("Loan amount must be greater than zero.")
            if tenure_months <= 0:
                raise ValueError("Tenure must be at least 1 month.")

            monthly_emi = Decimal(str(calculate_emi(amount, interest_rate, tenure_months)))

            cursor.execute("""
                INSERT INTO loans (customer_id, amount, purpose, interest_rate, tenure_months, monthly_emi, status)
                VALUES (%s, %s, %s, %s, %s, %s, 'Pending')
            """, (customer_id, amount, purpose, interest_rate, tenure_months, monthly_emi))
            conn.commit()
            flash(f"Loan application for ₹{amount} submitted! Estimated monthly EMI: ₹{monthly_emi}.", "success")
        except (ValueError, InvalidOperation) as e:
            conn.rollback()
            flash(str(e), "error")
        except mysql.connector.Error as e:
            conn.rollback()
            flash(f"Loan application failed: {str(e)}", "error")

    cursor.execute("""
        SELECT l.*, c.full_name, c.email, c.phone
        FROM loans l
        JOIN customers c ON l.customer_id = c.customer_id
        ORDER BY l.loan_id DESC
    """)
    loan_list = cursor.fetchall()

    cursor.execute("SELECT customer_id, full_name FROM customers ORDER BY full_name")
    customer_list = cursor.fetchall()

    cursor.close()
    conn.close()
    return render_template("loans.html", loans=loan_list, customers=customer_list)


@app.route("/loans/approve/<int:loan_id>", methods=["POST"])
@login_required
def approve_loan(loan_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    try:
        conn.start_transaction()
        cursor.execute("SELECT * FROM loans WHERE loan_id = %s FOR UPDATE", (loan_id,))
        loan = cursor.fetchone()

        if not loan or loan["status"] != "Pending":
            raise ValueError("Loan application not eligible for approval.")

        # Find customer's primary account to disburse funds
        cursor.execute("SELECT account_id, account_number FROM accounts WHERE customer_id = %s AND status = 'Active' LIMIT 1", (loan["customer_id"],))
        target_account = cursor.fetchone()

        if not target_account:
            raise ValueError("Customer does not have an active account to disburse loan funds into.")

        # Update loan status
        cursor.execute("UPDATE loans SET status = 'Approved' WHERE loan_id = %s", (loan_id,))

        # Disburse amount into target account
        cursor.execute("UPDATE accounts SET balance = balance + %s WHERE account_id = %s", (loan["amount"], target_account["account_id"]))

        # Log disbursement transaction
        cursor.execute("""
            INSERT INTO transactions (account_id, transaction_type, amount, description)
            VALUES (%s, 'Deposit', %s, %s)
        """, (target_account["account_id"], loan["amount"], f"Loan #{loan_id} Disbursal - {loan['purpose']}"))

        conn.commit()
        flash(f"Loan #{loan_id} for ₹{loan['amount']} APPROVED and disbursed into Account {target_account['account_number']}!", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Error approving loan: {str(e)}", "error")
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for("loans"))


@app.route("/loans/reject/<int:loan_id>", methods=["POST"])
@login_required
def reject_loan(loan_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("UPDATE loans SET status = 'Rejected' WHERE loan_id = %s AND status = 'Pending'", (loan_id,))
        conn.commit()
        flash(f"Loan application #{loan_id} has been rejected.", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Error rejecting loan: {str(e)}", "error")
    finally:
        cursor.close()
        conn.close()
    return redirect(url_for("loans"))


# ---------- AI PREDICTIVE ANALYTICS SUITE ----------

@app.route("/analytics")
@login_required
def analytics():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # 1. Total volume & averages
    cursor.execute("""
        SELECT
            COUNT(*) AS total_tx,
            COALESCE(AVG(amount), 0) AS avg_tx,
            COALESCE(MAX(amount), 0) AS max_tx,
            COALESCE(SUM(CASE WHEN transaction_type IN ('Deposit', 'Transfer In') THEN amount ELSE 0 END), 0) AS total_inflow,
            COALESCE(SUM(CASE WHEN transaction_type IN ('Withdraw', 'Transfer Out') THEN amount ELSE 0 END), 0) AS total_outflow
        FROM transactions
    """)
    stats = cursor.fetchone()

    # 2. Anomaly / High-Risk Transactions Detection
    # Any transaction greater than 2.5x the average transaction size is flagged for review
    cursor.execute("""
        SELECT t.*, a.account_number, c.full_name
        FROM transactions t
        JOIN accounts a ON t.account_id = a.account_id
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE t.amount > 10000
        ORDER BY t.amount DESC
        LIMIT 5
    """)
    flagged_tx = cursor.fetchall()

    # 3. Customer Credit Score Analysis
    cursor.execute("""
        SELECT c.customer_id, c.full_name, c.email,
               COUNT(DISTINCT a.account_id) AS account_count,
               COALESCE(SUM(a.balance), 0) AS total_balance,
               COUNT(DISTINCT t.transaction_id) AS tx_count,
               COUNT(DISTINCT CASE WHEN l.status = 'Approved' THEN l.loan_id END) AS active_loans
        FROM customers c
        LEFT JOIN accounts a ON c.customer_id = a.customer_id
        LEFT JOIN transactions t ON a.account_id = t.account_id
        LEFT JOIN loans l ON c.customer_id = l.customer_id
        GROUP BY c.customer_id
    """)
    customers_raw = cursor.fetchall()

    analyzed_customers = []
    for cust in customers_raw:
        # Dynamic Credit Score calculation (300 to 850)
        score = 650
        bal = float(cust["total_balance"])
        tx = cust["tx_count"]
        loans_count = cust["active_loans"]

        if bal > 50000:
            score += 100
        elif bal > 10000:
            score += 60
        elif bal < 1000:
            score -= 40

        score += min(50, tx * 10)
        if loans_count > 0:
            score += 30

        score = max(350, min(850, score))
        risk_tier = "Prime / Low Risk" if score >= 750 else ("Fair / Moderate" if score >= 600 else "High Risk")
        max_loan_offer = int(bal * 3 + 50000)

        analyzed_customers.append({
            **cust,
            "credit_score": score,
            "risk_tier": risk_tier,
            "preapproved_loan": max_loan_offer
        })

    # 4. 30-Day Predictive Cash Flow Forecast
    inflow = float(stats["total_inflow"])
    outflow = float(stats["total_outflow"])
    net_velocity = (inflow - outflow) / 30.0 if inflow or outflow else 0.0

    cursor.execute("SELECT COALESCE(SUM(balance), 0) AS total_bal FROM accounts")
    current_reserves = float(cursor.fetchone()["total_bal"])
    forecast_30d = round(current_reserves + (net_velocity * 30), 2)
    forecast_60d = round(current_reserves + (net_velocity * 60), 2)

    cursor.close()
    conn.close()

    return render_template(
        "analytics.html",
        stats=stats,
        flagged_tx=flagged_tx,
        analyzed_customers=analyzed_customers,
        current_reserves=current_reserves,
        forecast_30d=forecast_30d,
        forecast_60d=forecast_60d,
        net_velocity=round(net_velocity, 2)
    )


# ---------- REPORTS & PASSBOOK STATEMENT ----------

@app.route("/reports")
@login_required
def reports():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT COUNT(*) AS total_customers FROM customers")
    total_customers = cursor.fetchone()["total_customers"]

    cursor.execute("SELECT COUNT(*) AS total_accounts, COALESCE(SUM(balance), 0) AS total_balance FROM accounts")
    acc_stat = cursor.fetchone()
    total_accounts = acc_stat["total_accounts"]
    total_balance = acc_stat["total_balance"]

    cursor.execute("""
        SELECT transaction_type, COUNT(*) AS count, COALESCE(SUM(amount), 0) AS total
        FROM transactions
        GROUP BY transaction_type
    """)
    transaction_summary = cursor.fetchall()

    cursor.execute("SELECT COUNT(*) AS total_transactions FROM transactions")
    total_transactions = cursor.fetchone()["total_transactions"]

    # Filterable ledger
    account_id = request.args.get("account_id", "").strip()
    query = """
        SELECT t.*, a.account_number, c.full_name
        FROM transactions t
        JOIN accounts a ON t.account_id = a.account_id
        JOIN customers c ON a.customer_id = c.customer_id
        WHERE 1=1
    """
    params = []
    if account_id:
        query += " AND t.account_id = %s"
        params.append(account_id)
    query += " ORDER BY t.transaction_date DESC LIMIT 40"

    cursor.execute(query, tuple(params))
    ledger_transactions = cursor.fetchall()

    cursor.execute("""
        SELECT a.account_id, a.account_number, c.full_name
        FROM accounts a
        JOIN customers c ON a.customer_id = c.customer_id
        ORDER BY c.full_name
    """)
    accounts_list = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template(
        "reports.html",
        total_customers=total_customers,
        total_accounts=total_accounts,
        total_balance=total_balance,
        transaction_summary=transaction_summary,
        total_transactions=total_transactions,
        transactions=ledger_transactions,
        accounts=accounts_list,
        selected_account=account_id
    )


# ---------- SUPERCHARGED AI BANKING ASSISTANT ----------

@app.route("/assistant", methods=["GET", "POST"])
@login_required
def assistant():
    answer = None
    question = ""

    if request.method == "POST":
        question = request.form.get("question", "").strip()
        q_lower = question.lower()

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        # Dynamic AI Assistant response logic
        if not q_lower:
            answer = "Please enter a question or choose one of the suggested prompts below."
        elif any(w in q_lower for w in ["vanakkam", "hello", "hi", "hey"]):
            answer = f"👋 Vanakkam! Welcome to NIVRA AI Predictive Banking System. I'm your intelligent banking assistant. How can I assist you with accounts, transfers, loans, or analytics today?"
        elif any(w in q_lower for w in ["total customer", "how many customer", "ethana customer", "customers count"]):
            cursor.execute("SELECT COUNT(*) AS c FROM customers")
            c = cursor.fetchone()["c"]
            answer = f"📊 NIVRA Bank currently has **{c}** registered customers on file."
        elif any(w in q_lower for w in ["total balance", "bank reserve", "balance evlo", "total money"]):
            cursor.execute("SELECT COALESCE(SUM(balance), 0) AS bal FROM accounts")
            bal = cursor.fetchone()["bal"]
            answer = f"💰 The total live reserves across all accounts in NIVRA Bank is **₹{bal:,.2f}**."
        elif any(w in q_lower for w in ["transfer", "money transfer", "fund transfer", "send money", "anupuradhu"]):
            answer = (
                "💸 **How to Transfer Funds in NIVRA:**\n"
                "1. Go to the **Transactions** page from the sidebar.\n"
                "2. Choose the **Transfer** tab in the transaction form.\n"
                "3. Select your sender account, type the recipient's Account Number (e.g., NIVRA100001), enter the amount and remarks.\n"
                "4. Funds are transferred instantly with double-entry cryptographic verification!"
            )
        elif any(w in q_lower for w in ["fd", "fixed deposit", "interest rate", "savings rate", "vatti"]):
            answer = (
                "📈 **NIVRA Fixed Deposit & Interest Rates (2026):**\n"
                "• 6 Months: **6.50% p.a.**\n"
                "• 1 Year (12 Months): **7.25% p.a.**\n"
                "• 2 Years (24 Months): **7.50% p.a.**\n"
                "• 3 Years (36 Months): **8.00% p.a.**\n"
                "• 5 Years (60 Months): **8.50% p.a.** (Maximum return)\n\n"
                "You can create an FD directly from the **Fixed Deposits** tab!"
            )
        elif any(w in q_lower for w in ["card", "debit card", "atm", "freeze", "pin", "cvv"]):
            answer = (
                "💳 **NIVRA Virtual Debit Cards:**\n"
                "Every customer account is equipped with a contactless RuPay/Visa Platinum virtual debit card. "
                "You can view card numbers, flip for CVV, and instantly **Freeze/Unfreeze** cards from the **Debit Cards** menu."
            )
        elif any(w in q_lower for w in ["emi", "calculate emi", "loan calculator", "monthly emi"]):
            answer = (
                "🧮 **NIVRA Live EMI Calculator:**\n"
                "You can simulate personal and business loans on the **Loans** page. For example, a loan of ₹1,00,000 at 9.5% for 12 months has an estimated EMI of **₹8,768/month**."
            )
        elif any(w in q_lower for w in ["loan", "apply loan", "loan eligibility", "kadan"]):
            answer = (
                "📋 **Loan Services:**\n"
                "Visit the **Loans** page to apply for new loans or check status. Once submitted, bank managers can instantly approve and disburse funds directly to the customer's savings account."
            )
        elif any(w in q_lower for w in ["health", "score", "predict", "predictive", "credit score"]):
            answer = (
                "🤖 **AI Predictive Banking Suite:**\n"
                "Check the **AI Insights** page to view live financial health scores, 30-day cash reserve forecasts, anomaly fraud radar, and customer credit scores (300-850)."
            )
        else:
            answer = (
                f"🤖 I've analyzed your question: '{question}'.\n\n"
                "You can ask me about:\n"
                "• Live bank stats: 'Total customers', 'Total balance', 'Recent transactions'\n"
                "• Services: 'How to transfer money', 'Fixed deposit interest rates', 'Debit card freeze'\n"
                "• Loans & AI: 'Calculate EMI', 'Check credit score rules'."
            )

        cursor.close()
        conn.close()

    return render_template("assistant.html", answer=answer, question=question)


# ---------- API ENDPOINT FOR QUICK DASHBOARD CHARTS ----------

@app.route("/api/chart-data")
@login_required
def chart_data():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("""
        SELECT
            DATE(transaction_date) as tx_date,
            SUM(CASE WHEN transaction_type IN ('Deposit', 'Transfer In') THEN amount ELSE 0 END) as inflow,
            SUM(CASE WHEN transaction_type IN ('Withdraw', 'Transfer Out') THEN amount ELSE 0 END) as outflow
        FROM transactions
        GROUP BY DATE(transaction_date)
        ORDER BY tx_date ASC
        LIMIT 7
    """)
    rows = cursor.fetchall()

    cursor.execute("""
        SELECT account_type, COUNT(*) as cnt
        FROM accounts
        GROUP BY account_type
    """)
    acc_types = cursor.fetchall()

    cursor.close()
    conn.close()

    labels = [str(r["tx_date"]) for r in rows] or ["Today"]
    inflows = [float(r["inflow"]) for r in rows] or [0]
    outflows = [float(r["outflow"]) for r in rows] or [0]

    type_labels = [r["account_type"] for r in acc_types]
    type_counts = [r["cnt"] for r in acc_types]

    return jsonify({
        "labels": labels,
        "inflows": inflows,
        "outflows": outflows,
        "type_labels": type_labels,
        "type_counts": type_counts
    })


if __name__ == "__main__":
    try:
        initialize_database()
        print(">>> NIVRA AI Predictive Banking System DB successfully initialized.")
    except Exception as error:
        print(">>> Database initialization warning:", error)

    app.run(debug=True, port=5000)
