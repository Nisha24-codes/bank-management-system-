// ========================================================
// NIVRA BANKING - CLIENT INTERACTIVITY & CALCULATORS
// ========================================================

document.addEventListener("DOMContentLoaded", function () {
    // 1. TABS SYSTEM
    const tabBtns = document.querySelectorAll(".tab-btn");
    tabBtns.forEach(btn => {
        btn.addEventListener("click", function () {
            const tabGroup = this.getAttribute("data-group") || "default";
            const targetId = this.getAttribute("data-target");

            // Deactivate sibling buttons
            document.querySelectorAll(`.tab-btn[data-group="${tabGroup}"]`).forEach(b => b.classList.remove("active"));
            this.classList.add("active");

            // Hide sibling tab contents
            document.querySelectorAll(`.tab-content[data-group="${tabGroup}"]`).forEach(content => content.classList.remove("active"));
            const target = document.getElementById(targetId);
            if (target) {
                target.classList.add("active");
            }
        });
    });

    // 2. LIVE EMI CALCULATOR (Loans page)
    const emiAmount = document.getElementById("emi_loan_amount");
    const emiRate = document.getElementById("emi_interest_rate");
    const emiTenure = document.getElementById("emi_tenure_months");

    function calculateEMI() {
        if (!emiAmount || !emiRate || !emiTenure) return;

        const p = parseFloat(emiAmount.value) || 0;
        const r = (parseFloat(emiRate.value) || 0) / (12 * 100);
        const n = parseInt(emiTenure.value) || 0;

        let emi = 0;
        let totalPayment = 0;
        let totalInterest = 0;

        if (p > 0 && n > 0) {
            if (r === 0) {
                emi = p / n;
            } else {
                emi = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
            }
            totalPayment = emi * n;
            totalInterest = totalPayment - p;
        }

        const emiDisplay = document.getElementById("emi_result_val");
        const totalInterestDisplay = document.getElementById("emi_total_interest");
        const totalPaymentDisplay = document.getElementById("emi_total_payment");

        if (emiDisplay) emiDisplay.innerText = "₹" + emi.toLocaleString("en-IN", { maximumFractionDigits: 2 });
        if (totalInterestDisplay) totalInterestDisplay.innerText = "₹" + totalInterest.toLocaleString("en-IN", { maximumFractionDigits: 2 });
        if (totalPaymentDisplay) totalPaymentDisplay.innerText = "₹" + totalPayment.toLocaleString("en-IN", { maximumFractionDigits: 2 });
    }

    if (emiAmount && emiRate && emiTenure) {
        emiAmount.addEventListener("input", calculateEMI);
        emiRate.addEventListener("input", calculateEMI);
        emiTenure.addEventListener("input", calculateEMI);
        calculateEMI();
    }

    // 3. LIVE FIXED DEPOSIT CALCULATOR
    const fdPrincipal = document.getElementById("fd_calc_principal");
    const fdTenure = document.getElementById("fd_calc_tenure");

    function calculateFD() {
        if (!fdPrincipal || !fdTenure) return;

        const p = parseFloat(fdPrincipal.value) || 0;
        const months = parseInt(fdTenure.value) || 12;

        const rateMap = { 6: 6.5, 12: 7.25, 24: 7.5, 36: 8.0, 60: 8.5 };
        const rate = rateMap[months] || 7.0;

        const t = months / 12.0;
        const maturity = p * Math.pow(1 + ((rate / 100.0) / 4.0), 4 * t);
        const interest = maturity - p;

        const matDisplay = document.getElementById("fd_maturity_display");
        const intDisplay = document.getElementById("fd_interest_display");
        const rateDisplay = document.getElementById("fd_rate_display");

        if (matDisplay) matDisplay.innerText = "₹" + maturity.toLocaleString("en-IN", { maximumFractionDigits: 2 });
        if (intDisplay) intDisplay.innerText = "₹" + interest.toLocaleString("en-IN", { maximumFractionDigits: 2 });
        if (rateDisplay) rateDisplay.innerText = rate + "% p.a.";
    }

    if (fdPrincipal && fdTenure) {
        fdPrincipal.addEventListener("input", calculateFD);
        fdTenure.addEventListener("change", calculateFD);
        calculateFD();
    }

    // 4. CARD SENSITIVE DATA TOGGLE
    const toggleCardBtns = document.querySelectorAll(".toggle-card-btn");
    toggleCardBtns.forEach(btn => {
        btn.addEventListener("click", function () {
            const cardId = this.getAttribute("data-card");
            const numEl = document.getElementById(`card_num_${cardId}`);
            const cvvEl = document.getElementById(`card_cvv_${cardId}`);

            if (numEl) {
                const isMasked = numEl.getAttribute("data-masked") === "true";
                if (isMasked) {
                    numEl.innerText = numEl.getAttribute("data-real");
                    numEl.setAttribute("data-masked", "false");
                    this.innerText = "🔒 Hide Details";
                    if (cvvEl) cvvEl.innerText = cvvEl.getAttribute("data-real");
                } else {
                    const real = numEl.getAttribute("data-real");
                    numEl.innerText = "•••• •••• •••• " + real.slice(-4);
                    numEl.setAttribute("data-masked", "true");
                    this.innerText = "👁️ View Details";
                    if (cvvEl) cvvEl.innerText = "•••";
                }
            }
        });
    });

    // 5. CHAT ASSISTANT PROMPT CHIPS
    const promptChips = document.querySelectorAll(".chip");
    const chatInput = document.getElementById("question");
    promptChips.forEach(chip => {
        chip.addEventListener("click", function () {
            if (chatInput) {
                chatInput.value = this.innerText;
                chatInput.focus();
            }
        });
    });

    // 6. QUICK TABLE FILTER / SEARCH
    const searchInputs = document.querySelectorAll(".table-search-input");
    searchInputs.forEach(input => {
        input.addEventListener("keyup", function () {
            const tableId = this.getAttribute("data-table");
            const filter = this.value.toLowerCase();
            const table = document.getElementById(tableId);
            if (!table) return;

            const rows = table.getElementsByTagName("tr");
            for (let i = 1; i < rows.length; i++) {
                const text = rows[i].textContent.toLowerCase();
                rows[i].style.display = text.includes(filter) ? "" : "none";
            }
        });
    });
});
